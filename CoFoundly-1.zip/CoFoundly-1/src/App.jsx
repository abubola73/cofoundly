import React, { useState } from "react";
import { auth } from "./lib/firebase"; // Importa Firebase auth
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";
import Chat from "./components/Chat";

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Funzione per registrare un nuovo utente
  const handleSignup = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      setLoggedIn(true);
    } catch (error) {
      alert(error.message);
    }
  };

  // Funzione per fare login
  const handleLogin = async () => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      setLoggedIn(true);
    } catch (error) {
      alert(error.message);
    }
  };

  // Funzione per fare logout
  const handleLogout = async () => {
    await signOut(auth);
    setLoggedIn(false);
  };

  if (!loggedIn) {
    return (
      <div style={{ padding: "2rem" }}>
        <h1>Login o Registrazione</h1>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        /><br />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        /><br />
        <button onClick={handleLogin}>Login</button>
        <button onClick={handleSignup}>Registrati</button>
      </div>
    );
  }

  return (
    <div style={{ padding: "2rem" }}>
      <h1>Benvenuto su CoFoundly 🎓🤝</h1>
      <button onClick={handleLogout}>Logout</button>
      <Chat />
    </div>
  );
}

export default App;
