import React, { useEffect, useState } from "react";
import { auth, db } from "../lib/firebase";
import {
  collection,
  addDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from "firebase/firestore";

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const user = auth.currentUser;

  // Recupera i messaggi in tempo reale da Firestore
  useEffect(() => {
    const q = query(collection(db, "messages"), orderBy("timestamp"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMessages(
        snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }))
      );
    });
    return () => unsubscribe();
  }, []);

  // Invia un nuovo messaggio
  const sendMessage = async () => {
    if (newMessage.trim() === "") return;
    await addDoc(collection(db, "messages"), {
      text: newMessage,
      timestamp: serverTimestamp(),
      author: user.email, // assegna l'autore
    });
    setNewMessage("");
  };

  return (
    <div style={{ marginTop: "2rem", borderTop: "1px solid #ccc", paddingTop: "1rem" }}>
      <h3>Chat tra utenti</h3>

      <div style={{
        maxHeight: "300px",
        overflowY: "auto",
        marginBottom: "1rem",
        border: "1px solid #ccc",
        borderRadius: "8px",
        padding: "0.5rem"
      }}>
        {messages.map((msg) => {
          const isMe = msg.author === user?.email;
          return (
            <div
              key={msg.id}
              style={{
                textAlign: isMe ? "right" : "left",
                marginBottom: "0.5rem",
              }}
            >
              <div
                style={{
                  display: "inline-block",
                  backgroundColor: isMe ? "#dcf8c6" : "#f1f0f0",
                  color: "#000",
                  borderRadius: "1rem",
                  padding: "0.5rem 1rem",
                  maxWidth: "60%",
                }}
              >
                <small style={{ fontSize: "0.75rem", opacity: 0.7 }}>
                  {msg.author || "Anonimo"}
                </small>
                <br />
                {msg.text}
              </div>
            </div>
          );
        })}
      </div>

      <input
        type="text"
        placeholder="Scrivi un messaggio..."
        value={newMessage}
        onChange={(e) => setNewMessage(e.target.value)}
        style={{ marginRight: "0.5rem" }}
      />
      <button onClick={sendMessage}>Invia</button>
    </div>
  );
}
